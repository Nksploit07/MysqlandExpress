const sql=require('mysql2');


const con=sql.createConnection({
    host: "containers-us-west-33.railway.app",
    user: "root",
    password:"9LsOx7FzR4yh1LXPboHN",
    port:'6248',
    insecureAuth : false
});


con.connect((err)=>{
if(err){
    console.log(err);
}
else{
    console.log("connetion created!");
    con.query("show databases",(err,data)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log("database created successfully"+data);
        }
    });
    con.query("show databases",(err,data)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log(data);
            con.end();
        }
    })
}

});